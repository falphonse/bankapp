from django.apps import AppConfig


class BankManagementConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "bank_management"
